#include "AudioRenderer.h"
#include "Logger.h"

#include <QAudioDevice>
#include <QMediaDevices>
#include <cstring>

AudioRenderer::AudioRenderer(AudioFrameQueue* queue,
                             ClockSync*       clock,
                             QObject*         parent)
    : QThread(parent)
    , m_queue(queue)
    , m_clock(clock)
{
    m_byteRate = TARGET_SAMPLE_RATE * TARGET_CHANNELS * sizeof(float);
}

AudioRenderer::~AudioRenderer()
{
    stopRenderer();
    wait();
}

// ─────────────────────────────────────────────────────────────────────────────
// 主线程控制接口
// ─────────────────────────────────────────────────────────────────────────────
void AudioRenderer::setVolume(float v)
{
    QMutexLocker lk(&m_paramMutex);
    m_volume = qBound(0.0f, v, 1.0f);
    if (m_sink) m_sink->setVolume(m_muted ? 0.0f : m_volume);
}

void AudioRenderer::setMuted(bool muted)
{
    QMutexLocker lk(&m_paramMutex);
    m_muted = muted;
    if (m_sink) m_sink->setVolume(muted ? 0.0f : m_volume);
}

void AudioRenderer::setPaused(bool paused)
{
    m_paused.storeRelaxed(paused ? 1 : 0);
    if (m_sink) {
        if (paused) m_sink->suspend();
        else        m_sink->resume();
    }
}

void AudioRenderer::stopRenderer()
{
    m_stop.storeRelaxed(1);
    m_queue->abort();
}

void AudioRenderer::flush()
{
    m_flush.storeRelaxed(1);
    m_totalBytesWritten = 0;
    m_clock->invalidate();
}

void AudioRenderer::setSourceFormat(int sampleRate, int channels, AVSampleFormat fmt)
{
    m_srcSampleRate = sampleRate;
    m_srcChannels   = channels;
    m_srcFmt        = fmt;
}

// ─────────────────────────────────────────────────────────────────────────────
// 线程主函数
// ─────────────────────────────────────────────────────────────────────────────
void AudioRenderer::run()
{
    LOG_INFO("AudioRenderer thread started");

    // QAudioSink 必须在使用它的线程里创建
    QAudioFormat fmt;
    fmt.setSampleRate(TARGET_SAMPLE_RATE);
    fmt.setChannelCount(TARGET_CHANNELS);
    fmt.setSampleFormat(QAudioFormat::Float);

    const QAudioDevice defaultDevice = QMediaDevices::defaultAudioOutput();
    m_sink   = new QAudioSink(defaultDevice, fmt);
    m_device = m_sink->start();

    {
        QMutexLocker lk(&m_paramMutex);
        m_sink->setVolume(m_muted ? 0.0f : m_volume);
    }

    if (!m_device) {
        emit errorOccurred("AudioRenderer: 无法打开音频输出设备");
        delete m_sink;
        m_sink = nullptr;
        return;
    }

    // 初始化重采样器
    if (!initSwrContext()) {
        emit errorOccurred("AudioRenderer: 重采样器初始化失败");
        m_sink->stop();
        delete m_sink;
        m_sink = nullptr;
        return;
    }

    LOG_INFO("AudioRenderer: QAudioSink started, byteRate={}", m_byteRate);

    // ── 主渲染循环 ────────────────────────────────────────────────────────────
    VideoFrameQueue::Entry entry; // 复用 Entry 结构（AVFramePtr + serial + eof）
    while (!m_stop.loadRelaxed()) {

        // flush 请求（seek）
        if (m_flush.loadRelaxed()) {
            m_flush.storeRelaxed(0);
            m_totalBytesWritten = 0;
            if (m_swrCtx) swr_init(m_swrCtx.get()); // 重置重采样内部状态
        }

        if (!m_queue->pop(entry)) break; // abort

        if (entry.eof) {
            // 音频流结束，等待下一个文件
            m_clock->invalidate();
            continue;
        }

        if (!entry.frame) continue;

        renderFrame(entry.frame.get());
    }

    m_sink->stop();
    delete m_sink;
    m_sink   = nullptr;
    m_device = nullptr;

    LOG_INFO("AudioRenderer thread exiting");
}

// ─────────────────────────────────────────────────────────────────────────────
// 初始化 libswresample 重采样器
// ─────────────────────────────────────────────────────────────────────────────
bool AudioRenderer::initSwrContext()
{
    SwrContext* swr = nullptr;

    // 源声道布局
    AVChannelLayout srcLayout = AV_CHANNEL_LAYOUT_STEREO;
    if (m_srcChannels == 1)
        srcLayout = AV_CHANNEL_LAYOUT_MONO;

    // 目标声道布局（固定立体声）
    AVChannelLayout dstLayout = AV_CHANNEL_LAYOUT_STEREO;

    int ret = swr_alloc_set_opts2(
        &swr,
        &dstLayout,          // 目标声道布局
        AV_SAMPLE_FMT_FLTP,  // 目标格式（float planar，QAudioFormat::Float 对应）
        TARGET_SAMPLE_RATE,  // 目标采样率
        &srcLayout,          // 源声道布局
        m_srcFmt,            // 源格式
        m_srcSampleRate,     // 源采样率
        0, nullptr
    );

    if (ret < 0 || !swr) {
        LOG_ERROR("AudioRenderer: swr_alloc_set_opts2 failed: {}", av_err(ret));
        return false;
    }

    ret = swr_init(swr);
    if (ret < 0) {
        swr_free(&swr);
        LOG_ERROR("AudioRenderer: swr_init failed: {}", av_err(ret));
        return false;
    }

    m_swrCtx.reset(swr);
    LOG_INFO("AudioRenderer: swresample OK — {}Hz {}ch {} → {}Hz {}ch float",
             m_srcSampleRate, m_srcChannels, av_get_sample_fmt_name(m_srcFmt),
             TARGET_SAMPLE_RATE, TARGET_CHANNELS);
    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// 渲染单帧音频
// ─────────────────────────────────────────────────────────────────────────────
void AudioRenderer::renderFrame(AVFrame* frame)
{
    if (!m_swrCtx || !m_device) return;

    // 计算重采样后的样本数
    const int dstSamples = static_cast<int>(
        av_rescale_rnd(
            swr_get_delay(m_swrCtx.get(), m_srcSampleRate) + frame->nb_samples,
            TARGET_SAMPLE_RATE, m_srcSampleRate, AV_ROUND_UP));

    // 分配输出缓冲
    // float planar：每个声道独立缓冲，交织（interleaved）写入 QAudioSink
    const int bufSize = dstSamples * TARGET_CHANNELS * sizeof(float);
    std::vector<uint8_t> outBuf(bufSize);
    uint8_t* outData = outBuf.data();

    int ret = swr_convert(m_swrCtx.get(),
                          &outData, dstSamples,
                          const_cast<const uint8_t**>(frame->data),
                          frame->nb_samples);
    if (ret < 0) {
        LOG_WARN("AudioRenderer: swr_convert failed: {}", av_err(ret));
        return;
    }

    // swr_convert 输出的是 planar float，需要交织（interleave）再写入
    // 对于 AV_SAMPLE_FMT_FLTP，outData 是 ch0 连续然后 ch1 连续
    // QAudioSink 期望的是 [L0,R0,L1,R1,...] 交织格式
    // 交织转换
    const int actualSamples = ret;
    std::vector<float> interleaved(actualSamples * TARGET_CHANNELS);
    const float* ch0 = reinterpret_cast<const float*>(outData);
    const float* ch1 = ch0 + actualSamples; // planar：ch1 紧跟 ch0 之后

    for (int i = 0; i < actualSamples; ++i) {
        interleaved[i * 2]     = ch0[i];
        interleaved[i * 2 + 1] = (TARGET_CHANNELS > 1) ? ch1[i] : ch0[i];
    }

    const qint64 writeBytes = actualSamples * TARGET_CHANNELS * sizeof(float);

    // 分批写入（QAudioSink 内部有缓冲区，write 可能不完全写入）
    const char* ptr = reinterpret_cast<const char*>(interleaved.data());
    qint64 remaining = writeBytes;
    while (remaining > 0 && !m_stop.loadRelaxed()) {
        const qint64 written = m_device->write(ptr, remaining);
        if (written <= 0) {
            QThread::msleep(1); // 缓冲区满，稍等
            continue;
        }
        ptr       += written;
        remaining -= written;
        m_totalBytesWritten += written;
    }

    updateClock(m_totalBytesWritten);
}

// ─────────────────────────────────────────────────────────────────────────────
// 更新音频时钟
// ─────────────────────────────────────────────────────────────────────────────
void AudioRenderer::updateClock(qint64 totalBytes)
{
    if (m_byteRate <= 0) return;
    // 音频时钟 = 已写入字节 / 字节率（秒）→ 转微秒
    const qint64 clockUs = totalBytes * 1'000'000LL / m_byteRate;
    m_clock->setAudioClock(clockUs);

    // 每 100ms 发一次位置信号（不需要每帧都发）
    static qint64 lastEmitUs = 0;
    if (clockUs - lastEmitUs >= 100'000) {
        lastEmitUs = clockUs;
        emit positionChanged(clockUs / 1000);
    }
}
