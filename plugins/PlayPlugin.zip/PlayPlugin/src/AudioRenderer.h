#pragma once

#include "FrameQueue.h"
#include "ClockSync.h"
#include "FFmpegUtils.h"

#include <QThread>
#include <QAudioSink>
#include <QAudioFormat>
#include <QIODevice>
#include <QAtomicInt>
#include <QMutex>

/**
 * @brief AudioRenderer — 音频渲染线程
 *
 * 从 AudioFrameQueue 取 AVFrame，经 libswresample 重采样后
 * 写入 QAudioSink，同时维护音频时钟供视频同步使用。
 *
 * 输出格式固定为：
 *   采样率：48000 Hz（或跟随源，见 TARGET_SAMPLE_RATE）
 *   声道数：2（立体声）
 *   格式  ：Float（QAudioFormat::Float，32-bit float）
 *
 * 音频时钟计算：
 *   clock_us = (写入的总字节数 / 字节率) * 1_000_000
 *   字节率 = sample_rate × channels × sizeof(float)
 */
class AudioRenderer : public QThread
{
    Q_OBJECT

public:
    static constexpr int TARGET_SAMPLE_RATE = 48000;
    static constexpr int TARGET_CHANNELS    = 2;

    explicit AudioRenderer(AudioFrameQueue* queue,
                           ClockSync*       clock,
                           QObject*         parent = nullptr);
    ~AudioRenderer() override;

    // ── 主线程控制接口 ────────────────────────────────────────────────────────
    void setVolume(float v);       // 0.0 ~ 1.0
    void setMuted(bool muted);
    void setPaused(bool paused);
    void stopRenderer();
    void flush();                  // seek 时清空，配合 FrameQueue::flush()

    // 通知渲染器音频流参数（解码器 open 后调用）
    void setSourceFormat(int sampleRate, int channels, AVSampleFormat fmt);

signals:
    void positionChanged(qint64 posMs); // 当前音频播放位置（毫秒）
    void errorOccurred(const QString& msg);

protected:
    void run() override;

private:
    bool initSwrContext();
    void renderFrame(AVFrame* frame);
    void updateClock(qint64 bytesWritten);

    AudioFrameQueue* m_queue  = nullptr;
    ClockSync*       m_clock  = nullptr;

    // QAudioSink（在线程内创建，必须在同一线程销毁）
    QAudioSink*  m_sink   = nullptr;
    QIODevice*   m_device = nullptr;  // sink->start() 返回的写入设备

    // 重采样上下文
    SwrContextPtr m_swrCtx;

    // 源格式（由 setSourceFormat 设置）
    int            m_srcSampleRate = 44100;
    int            m_srcChannels   = 2;
    AVSampleFormat m_srcFmt        = AV_SAMPLE_FMT_FLTP;

    // 音频时钟
    qint64 m_totalBytesWritten = 0;
    int    m_byteRate          = 0; // TARGET_SAMPLE_RATE × TARGET_CHANNELS × 4

    // 控制
    QAtomicInt m_stop   { 0 };
    QAtomicInt m_paused { 0 };
    QAtomicInt m_flush  { 0 };

    float m_volume = 1.0f;
    bool  m_muted  = false;
    QMutex m_paramMutex; // 保护 volume / muted 的读写
};
